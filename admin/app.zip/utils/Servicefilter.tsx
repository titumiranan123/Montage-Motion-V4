/* eslint-disable @typescript-eslint/no-explicit-any */
"use client";

import { useQuery } from "@tanstack/react-query";
import React, { useEffect } from "react";
import { getDataCategory } from "./getCategory";
import { useRouter, useSearchParams } from "next/navigation";

export const ServiceFilter = ({
  slice = 0,
  others = [],
}: {
  slice?: number;
  others?: any[];
}) => {
  const router = useRouter();
  const searchParams = useSearchParams();
  const currentPage = searchParams.get("page");

  const { data } = useQuery({
    queryKey: ["categories"],
    queryFn: getDataCategory,
  });

  // ✅ Only runs after data arrives AND no page param is set yet
  useEffect(() => {
    if (!currentPage && data && data.length > 0) {
      router.replace(`?page=${data[slice]?.service_type}`);
    }
  }, [currentPage, data, router, slice]);

  const allTypes = [...(data ?? []), ...others];

  return (
    <select
      value={currentPage ?? data?.[slice]?.service_type ?? ""}
      onChange={(e) => router.push(`?page=${e.target.value}`)}
      className="bg-[#101828] border border-slate-300 rounded-lg p-2 text-white w-full md:w-50"
    >
      {allTypes?.slice(slice)?.map((item: any, idx: number) => (
        <option key={idx} value={item.service_type}>
          {item.service_title}
        </option>
      ))}
    </select>
  );
};
