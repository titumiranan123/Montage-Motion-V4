import { getData } from "@/utils/getDate";
import React from "react";
import FaqWrapper from "./FaqWrapper";

const Faqs = async ({
  searchParams,
}: {
  searchParams: Promise<{ page: string }>;
}) => {
  const { page } = await searchParams;
  const data = await getData({ slug: page ? `faq?page=${page}` : "faq" });
  return (
    <div className="text-gray-100 p-4 md:p-8">
      <FaqWrapper data={data?.[0] ?? null} />
    </div>
  );
};

export default Faqs;
