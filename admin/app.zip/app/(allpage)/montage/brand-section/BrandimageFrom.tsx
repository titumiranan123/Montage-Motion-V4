/* eslint-disable @typescript-eslint/no-explicit-any */
"use client";
import React, { useState } from "react";
import { useForm, SubmitHandler, useWatch } from "react-hook-form";
import { FiX } from "react-icons/fi";
import ImageUploader from "@/component/ImageUploader";
import { api_url } from "@/hook/Apiurl";
import toast from "react-hot-toast";
import { useRouter } from "next/navigation";
import { ServiceTypeSelect } from "@/utils/ServiceTypeseclect";

export interface IBrandImage {
  id?: string;
  image: string;
  alt: string;
  width: string;
  height: string;
  ishide: boolean;
  type: string;
}

interface BrandFormValues {
  image: string;
  alt: string;
  type: string;
  width: string;
  height: string;
  ishide: boolean;
}

interface BrandImageFormProps {
  initialValue?: IBrandImage | null;
  onClose: () => void;
}

const BrandImageFormModal: React.FC<BrandImageFormProps> = ({
  initialValue,
  onClose,
}) => {
  const router = useRouter();
  const {
    register,
    control,
    handleSubmit,
    setValue,
    formState: { errors },
  } = useForm<BrandFormValues>({
    defaultValues: initialValue
      ? {
          image: initialValue.image,
          alt: initialValue.alt,
          width: initialValue.width,
          height: initialValue.height,
          type: initialValue.type,
          ishide: initialValue.ishide,
        }
      : {
          image: "",
          alt: "",
          width: "",
          height: "",
          type: "",
          ishide: false,
        },
  });

  const selectedImage = useWatch({ control, name: "image" });
  const selectedType = useWatch({ control, name: "type" });

  const [isSubmitting, setIsSubmitting] = useState(false);

  const onSubmit: SubmitHandler<BrandFormValues> = async (data) => {
    try {
      setIsSubmitting(true);
      const responsce = initialValue?.id
        ? await api_url.patch(`/api/brand/images/${initialValue.id}`, data)
        : await api_url.post(`/api/brand/images`, data);
      if (responsce.status === 200 || responsce.status === 201) {
        toast.success(responsce.data.message);
        router.refresh();
      }
      onClose();
    } catch (error) {
      console.error("Error saving brand image:", error);
      toast.error("Could not save brand image");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="w-full max-w-4xl rounded-xl max-h-[86vh] overflow-y-scroll bg-slate-900     ">
      <div className="relative   p-8   text-white">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-3 right-3 text-gray-400 hover:text-white transition-colors"
        >
          <FiX size={22} />
        </button>

        <h2 className="text-2xl font-semibold mb-6 text-center">
          {initialValue ? "Edit Brand Image" : "Add Brand Image"}
        </h2>

        <form
          onSubmit={handleSubmit(onSubmit)}
          className="space-y-6 grid grid-cols-1 md:grid-cols-2 gap-5"
        >
          {/* Image Upload */}
          <div>
            <label className="block font-medium text-gray-200 mb-1">
              Image URL *
            </label>

            <div className="mt-3">
              <ImageUploader
                value={selectedImage}
                onChange={(url) =>
                  setValue("image", url, { shouldDirty: true, shouldValidate: true })
                }
              />
              <input
                {...register("image", { required: "Image is Required" })}
                type="text"
                className="hidden"
                placeholder=""
              />
            </div>
            {errors.image && (
              <p className="text-red-500 text-sm mt-1">
                {errors.image.message}
              </p>
            )}
          </div>

          {/* Alt Text */}
          <div className="space-y-6">
            <div>
              <label className="block font-medium text-gray-200 mb-1">
                Alt Text *
              </label>
              <input
                {...register("alt", { required: "Alt text is required" })}
                type="text"
                className="w-full p-3 bg-gray-900 border border-gray-700 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-[#1FA4C0] focus:border-[#1FA4C0] transition-colors"
                placeholder="Enter alt text"
              />
              {errors.alt && (
                <p className="text-red-500 text-sm mt-1">
                  {errors.alt.message}
                </p>
              )}
            </div>
            <div>
              <label className="block font-medium text-gray-200 mb-1">
                Image Height *
              </label>
              <input
                {...register("height", { required: "Height is required" })}
                type="text"
                className="w-full p-3 bg-gray-900 border border-gray-700 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-[#1FA4C0] focus:border-[#1FA4C0] transition-colors"
                placeholder="Enter image height"
              />
              {errors.height && (
                <p className="text-red-500 text-sm mt-1">
                  {errors.height.message}
                </p>
              )}
            </div>
            <div>
              <label className="block font-medium text-gray-200 mb-1">
                Image Width *
              </label>
              <input
                {...register("width", { required: "Width is required" })}
                type="text"
                className="w-full p-3 bg-gray-900 border border-gray-700 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-[#1FA4C0] focus:border-[#1FA4C0] transition-colors"
                placeholder="Enter image width"
              />
              {errors.width && (
                <p className="text-red-500 text-sm mt-1">
                  {errors.width.message}
                </p>
              )}
            </div>
          </div>

          {/* Type Field */}
          <div>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Page Type *
                </label>
                <div className="relative">
                  <ServiceTypeSelect
                    value={selectedType}
                    onChange={(url: any) => {
                      setValue(`type`, url, { shouldDirty: true, shouldValidate: true });
                    }}
                  />
                  <input
                    {...register("type", {
                      required: "Type is required",
                    })}
                    placeholder="e.g., Affordable Pricing, Premium Plans"
                    className="hidden"
                  />
                </div>
                {errors.type && (
                  <p className="text-sm text-red-400 mt-1">
                    {errors.type.message}
                  </p>
                )}
              </div>
            </div>
          </div>

          {/* Hide Field */}
          <div className="flex items-center space-x-3">
            <input
              {...register("ishide")}
              type="checkbox"
              id="ishide"
              className="w-4 h-4 text-[#1FA4C0] bg-gray-900 border-gray-700 rounded focus:ring-[#1FA4C0] focus:ring-2"
            />
            <label htmlFor="ishide" className="block font-medium text-gray-200">
              Hide Image
            </label>
          </div>

          {/* Buttons */}
          <div className="flex justify-end space-x-3 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="px-5 py-2.5 bg-gray-800 text-gray-300 rounded-lg hover:bg-gray-700 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-5 py-2.5 bg-[#1FA4C0] text-white rounded-lg hover:bg-[#1A8DA8] disabled:opacity-50 transition-colors"
            >
              {isSubmitting ? "Saving..." : "Save"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default BrandImageFormModal;
