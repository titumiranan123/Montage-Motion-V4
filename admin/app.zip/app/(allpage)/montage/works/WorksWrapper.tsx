/* eslint-disable react-hooks/set-state-in-effect */
/* eslint-disable @typescript-eslint/no-explicit-any */
"use client";
import { useDragAndDrop } from "@formkit/drag-and-drop/react";
import { useEffect, useRef, useState } from "react";
import Swal from "sweetalert2";
import { api_url } from "@/hook/Apiurl";
import VideoCard from "@/component/works/Workcard";
import Workform from "@/component/works/Workform";
import { ServiceFilter } from "@/utils/Servicefilter";
import { useRouter } from "next/navigation";
import WorkHeaderForm from "./Headerform";
import Heading from "../page-service/Headering";

interface IVideo {
  id?: string;
  title: string;
  description: string;
  thumbnail: string;
  video_link: string;
  is_visible: boolean;
  is_feature: boolean;
  position?: number;
  type: string;
}

export const WorkWrapper = ({ data }: { data: any }) => {
  const [isWork, setWorkModal] = useState(false);
  const [editData, setEditData] = useState<IVideo | null>(null);
  const router = useRouter();
  const [hasChanges, setHasChanges] = useState(false);
  const savedPositions = useRef("");
  const [parent, tapes, setTapes] = useDragAndDrop<HTMLDivElement, IVideo>(
    data?.works ?? [],
  );
  const [WorkEdit, setWorkEditData] = useState<any | null>();
  const [isHeaderModal, setWorkHeaderModal] = useState(false);

  useEffect(() => {
    if (data?.works) {
      setTapes(data.works);
      savedPositions.current = JSON.stringify(
        data.works.map((item: IVideo) => item.id),
      );
      setHasChanges(false);
    }
  }, [data, setTapes]);

  useEffect(() => {
    const currentPositions = JSON.stringify(
      (tapes ?? []).map((item) => item.id),
    );
    if (savedPositions.current) {
      setHasChanges(currentPositions !== savedPositions.current);
    }
  }, [tapes]);

  const savePositions = async () => {
    const payload = tapes.map((item, index) => ({
      id: item.id,
      position: index + 1,
      type: item.type,
    }));

    try {
      await api_url.patch("/api/works/positions", payload);
      savedPositions.current = JSON.stringify(
        tapes.map((item) => item.id),
      );
      Swal.fire({
        title: "Positions updated!",
        icon: "success",
        background: "#1f2937",
        color: "#fff",
        confirmButtonColor: "#6366f1",
      });
      router.refresh();
      setHasChanges(false);
    } catch (err: any) {
      Swal.fire({
        title: "Failed to update!",
        text: err.message,
        icon: "error",
        background: "#1f2937",
        color: "#fff",
        confirmButtonColor: "#6366f1",
      });
    }
  };

  const handleSubmit = async (data: IVideo) => {
    try {
      const res = await api_url.post(
        `/api/works${data.id ? `/${data.id}` : ""}`,
        data,
      );
      Swal.fire({
        title: res.data.message,
        icon: "success",
        background: "#1f2937",
        color: "#fff",
        confirmButtonColor: "#6366f1",
      });
      setWorkModal(false);
      setEditData(null);
    } catch (err: any) {
      Swal.fire({
        title: "Something went wrong!",
        text: err.message,
        icon: "error",
        background: "#1f2937",
        color: "#fff",
        confirmButtonColor: "#6366f1",
      });
    }
  };

  return (
    <div className="min-h-screen text-white p-6">
      {/* Header */}
      <div className="flex justify-between items-center mb-10">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold ">Works Gallery</h1>
          <p className="text-gray-400">Manage and showcase client Works</p>
        </div>
        <div className="flex gap-4">
          {hasChanges && (
            <button
              onClick={savePositions}
              className="bg-[#1FB5DD]/90 text-white px-4 py-2 rounded"
            >
              Save Positions
            </button>
          )}
          <ServiceFilter slice={0} />

          <div className="flex gap-4">
            <button
              onClick={() => {
                setWorkEditData(null);
                setWorkHeaderModal(true);
              }}
              className="bg-[#1FB5DD] text-white px-4 py-2 rounded"
            >
              + Add Work Header
            </button>
            <button
              onClick={() => {
                setEditData(null);
                setWorkModal(true);
              }}
              className="bg-[#1FB5DD] text-white px-4 py-2 rounded"
            >
              + Add Work
            </button>
          </div>
        </div>
      </div>
      <div>
        <Heading
          subtitle={data?.paragraph}
          title={data?.heading_part1}
          extratitle={data?.heading_part2}
          tag={data?.tag}
        />
        <div className="mx-auto mt-10 flex justify-center items-center">
          <button
            className="py-2 px-3 rounded-lg border border-[#1FB5DD]"
            onClick={() => {
              setWorkEditData({
                type: data?.type,
                tag: data?.tag,
                heading_part1: data?.heading_part1,
                paragraph: data?.paragraph,
              });
              setWorkHeaderModal(true);
            }}
          >
            Edit Header
          </button>
        </div>
        <div className="mt-10">
          {/* Grid */}
          {tapes?.length > 0 ? (
            <div ref={parent} className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {tapes?.map((item) => (
                <VideoCard
                  key={item.id}
                  video={item}
                  onEdit={() => {
                    setEditData(item);
                    setWorkModal(true);
                  }}
                />
              ))}
            </div>
          ) : (
            <p>No items found.</p>
          )}
        </div>
      </div>

      {/* Modal */}
      {isWork && (
        <div
          style={{ zIndex: 999 }}
          onClick={() => setWorkModal(false)}
          className="fixed inset-0 bg-black/40 backdrop-blur-sm bg-opacity-50 flex justify-center items-start p-8"
        >
          <div onClick={(e) => e.stopPropagation()} className="w-full">
            <Workform
              initialData={editData}
              onCancel={() => setWorkModal(false)}
              onSubmit={handleSubmit}
            />
          </div>
        </div>
      )}
      {isHeaderModal && (
        <div
          style={{ zIndex: 999 }}
          onClick={() => setWorkHeaderModal(false)}
          className="fixed inset-0 bg-black/40 backdrop-blur-sm bg-opacity-50 flex justify-center items-start p-8"
        >
          <div onClick={(e) => e.stopPropagation()} className="w-5xl">
            <WorkHeaderForm
              initialData={WorkEdit}
              setIsModalOpent={setWorkHeaderModal}
            />
          </div>
        </div>
      )}
    </div>
  );
};
