export interface ProcessStep {
  image: string
  alt: string;
  title: string;
  description: string;
  is_hidden: boolean;
}

export interface ProcessSchema {
  tag: string;
  heading_part1: string;
  heading_part2: string;
  paragraph: string;
  type: string;
  image?: string;
  alt?: string;
  ourstory_steps: ProcessStep[];
}
