/* eslint-disable @typescript-eslint/no-explicit-any */
"use client";
import Image from "next/image";
import React, { useEffect, useState } from "react";
import Gradientcard from "./Gradientcard";

const ProcessSlider = ({ data }: { data: any }) => {
  const [activeIndex, setActiveIndex] = useState(0);
  const steps = Array.isArray(data) ? data : [];
  useEffect(() => {
    const handleScroll = () => {
      const cards = document.querySelectorAll(".story-card");
      cards.forEach((card, index) => {
        const rect = card.getBoundingClientRect();
        if (
          rect.top < window.innerHeight / 2 &&
          rect.bottom > window.innerHeight / 2
        ) {
          setActiveIndex(index);
        }
      });
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  if (steps.length === 0) {
    return <p className="text-gray-400">No story steps found.</p>;
  }

  return (
    <div className=" flex lg:flex-row flex-col mt-9 md:mt-16 gap-12">
      <div className="sticky top-32 max-w-109.5 rounded-[13px] w-full max-h-124.5 h-full">
        <Image
          src={steps[activeIndex]?.image ?? steps[0]?.image ?? ""}
          alt="process "
          width={438}
          height={598}
          data-aos="fade-right"
          data-aos-delay={200}
          className="max-w-159.5 rounded-[13px] w-full max-h-224.5 h-full"
          priority
        />
      </div>

      <div className=" flex flex-col  gap-2">
        {steps.map((dt: any, idx: number) => {
          const result = activeIndex !== idx;
          return (
            <div
              key={idx}
              data-aos="fade-up"
              className="story-card"
              data-aos-delay={100 + idx * 100}
            >
              <Gradientcard
                isHover={result}
                className="contact-card flex justify-between lg:items-start text-(--text-primary) flex-col lg:flex-row max-w-175 w-full lg:h-42.5 h-80  rounded-3xl p-5 "
                borderClassName="max-w-[698px] w-full lg:h-[172px] h-80.5 rounded-[24px] p-[1px] group transition-transform duration-200 ease-in-out hover:scale-[104%]"
              >
              
                <div className="w-full">
                  <h3 className="font-semibold poppins text-[24px] ">
                    {dt?.title ?? ""}
                  </h3>
                  <p className=" font-normal text-[16px]">
                    {dt?.description ?? ""}
                  </p>
                </div>
              </Gradientcard>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default ProcessSlider;
