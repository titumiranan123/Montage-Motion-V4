/* eslint-disable @typescript-eslint/no-explicit-any */
import React from "react";
import axios from "axios";
import Whychoosewrapper from "./Whychoosewrapper";

const Page = async ({ searchParams }: { searchParams: any }) => {
  const { page } = await searchParams;
  const responsce = await axios.get(
    `${process.env.NEXT_PUBLIC_API_URL}/api/why-choose-us?type=${
      page ?? "home"
    }`,
  );
  return (
    <main className="min-h-screen  py-10">
      <Whychoosewrapper
        data={responsce?.data?.data}
        key={page ?? "home"}
      />
    </main>
  );
};

export default Page;
