/* eslint-disable @typescript-eslint/no-explicit-any */
import axios from "axios";
import Processwrapper from "./Processwrapper";

export default async function Page({ searchParams }: { searchParams: any }) {
  const { page } = await searchParams;
  const responsce = await axios.get(
    `${process.env.NEXT_PUBLIC_API_URL}/api/process?type=${page}`,
  );
  return (
    <main className="min-h-screen bg-black py-10">
      <Processwrapper data={responsce?.data?.data?.[0]} />
    </main>
  );
}
