import express from "express";
import cors from "cors";
import config from "./config";
import { logger } from "./logger/logger";

import cookieParser from "cookie-parser";
import { invalidateRoute } from "./midleware/invalideroute";
import mainRoute from "./main.route";
import globalErrorHandler from "./midleware/globalErrorHandler";
const app = express();
app.use(
  cors({
    origin: [
      "https://dashboard.montagemotion.com",
      "www.dashboard.montagemotion.com",
      "montagemotion.com",
      "https://montagemotion.com",
      "http://localhost:5001",
      "http://localhost:5000",
    ],
    methods: ["GET", "POST", "PUT", "PATCH", "DELETE"],
    credentials: true,
  })
);

app.use(cookieParser());
app.use(express.json({ limit: "500mb" }));
app.use(express.text({ type: "application/xml" }));
app.use(express.urlencoded({ extended: true, limit: "500mb" }));

app.use(mainRoute);
app.get("/", (_req, res) => {
  res.send("connected heloss asdf ");
});

app.use(invalidateRoute);
app.use(globalErrorHandler);

app.listen(config.port, () => {
  logger.info(
    `Server connect on ${config.port} this port: url : ${`http://localhost:${config.port}`}`
  );
});
