export interface MemberProfile {
  id?: string;
  name: string;
  designation?: string;
  photourl: string;
  alt?: string;
  position?: number;
  created_at?: string;
  updated_at?: string;
}
