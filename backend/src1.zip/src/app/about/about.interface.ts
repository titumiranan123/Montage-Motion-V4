export interface IAbout {
  id?: number;
  title: string;
  description: string;
  image: string;
  alt: string;
  created_at?: Date;
  updated_at?: Date;
}
