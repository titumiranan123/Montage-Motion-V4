export interface IService {
  title: string;
  description: string;
  image: string;
  isPublish: string;
  href: string;
  position: number;
  is_active: boolean;
}
