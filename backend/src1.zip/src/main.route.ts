import { Router } from "express";
import dashboardRoute from "./app/website/web.route";
import seoRoute from "./app/seo/seo.route";
import campaignRoutes from "./app/campaign-aplication/campaign.route";

import faqRoute from "./app/faq/faq.routes";
import headerRoute from "./app/header/header.routes";
import pricingRoute from "./app/pricing/pricing.route";
import testimonialRoute from "./app/testimonial/testimonial.route";
import recentRoute from "./app/work/work.route";
import contactRoute from "./app/contact/conatct.routes";
import AuthRoute from "./app/auth/auth.routes";
import faqRouter from "./app/faq/faq.routes";
import stateRouter from "./app/state/state.routes";
import serviceRoute from "./app/services/service.route";
import uploadRoute from "./app/upload/upload.route";
import aboutRoute from "./app/about/about.route";
import blogRoute from "./app/blogs/blog.route";
import webRoute from "./app/homeapis/homeapi.routes";
import memberRoute from "./app/member/member.route";
import robotsRoute from "./app/robots/robots.routes";
import siteMap from "./app/sitemap/sitemap.routes";
import workingProcess from "./app/working_process/process.route";
import pageServiceRoute from "./app/pageservice/page_service.route";
import videoRoute from "./app/video-upload/video.routes";
import bradImageRoute from "./app/brand_images/brandimage.route";
import pageWhychooseusRoute from "./app/whychooseus/whychooseus.route";
import carrerRoute from "./app/carrerpost/carrer.route";

const mainRoute = Router();

mainRoute.use("/api", faqRoute);
mainRoute.use("/api", headerRoute);
mainRoute.use("/api/pricing", pricingRoute);
mainRoute.use("/api/", testimonialRoute);
mainRoute.use("/api", recentRoute);
mainRoute.use("/api", AuthRoute);
mainRoute.use("/api", contactRoute);
mainRoute.use("/api", faqRouter);
mainRoute.use("/api", stateRouter);
mainRoute.use("/api", serviceRoute);
mainRoute.use("/api", aboutRoute);
mainRoute.use("/api", blogRoute);
mainRoute.use("/api", memberRoute);
mainRoute.use("/api", campaignRoutes);
mainRoute.use("/api", dashboardRoute);
// public page route
mainRoute.use("/api", webRoute);
// file upload route
mainRoute.use("/api", uploadRoute);
// seo routes
mainRoute.use("/api", siteMap);
mainRoute.use("/api", seoRoute);
mainRoute.use("/api", robotsRoute);
// new routes
mainRoute.use("/api/our-service", pageServiceRoute);
mainRoute.use("/api/process", workingProcess);
mainRoute.use("/api/why-choose-us", pageWhychooseusRoute);
mainRoute.use("/api/brand/images", bradImageRoute);
mainRoute.use("/api/jobpost", carrerRoute);
mainRoute.use("/api", videoRoute);
export default mainRoute;
