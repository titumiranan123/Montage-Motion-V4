/* eslint-disable @typescript-eslint/no-explicit-any */
import { db } from "../../db/db";
import { errorLogger } from "../../logger/logger";

const checkColumnExists = async (id: string) => {
  const res = await db.query(`SELECT 1 FROM comparison_columns WHERE id=$1`, [
    id,
  ]);
  if (res.rowCount === 0) throw new Error("Comparison column not found");
};

export const comparisonService = {
  /** ✅ Create comparison */
  async createComparison(data: any) {
    const client = await db.connect();

    try {
      await client.query("BEGIN");

      for (const column of data.columns) {
        const resCol = await client.query(
          `INSERT INTO comparison_columns
            (page, tag, heading_title, paragraph, type, title, image, bonus_title)
           VALUES ($1,$2,$3,$4,$5,$6,$7,$8)
           RETURNING id`,
          [
            data.page,
            data.tag,
            data.heading_title,
            data.paragraph,
            column.type,
            column.title ?? null,
            column.image ?? null,
            column.bonus_title ?? null,
          ],
        );

        const columnId = resCol.rows[0].id;

        for (const entry of column.entries) {
          if (entry.entry_type === "bonus" && column.type !== "montage") {
            throw new Error("Bonus entries allowed only for montage");
          }

          await client.query(
            `INSERT INTO comparison_entries
              (column_id, entry_type, text, position)
             VALUES ($1,$2,$3,$4)`,
            [columnId, entry.entry_type, entry.text, entry.position],
          );
        }
      }

      await client.query("COMMIT");
      return { message: "Comparison created successfully" };
    } catch (error) {
      await client.query("ROLLBACK");
      errorLogger.error(error);
      throw new Error("Failed to create comparison");
    } finally {
      client.release();
    }
  },

  /** ✅ Update single column */
  async updateComparison(columnId: string, data: any) {
    await checkColumnExists(columnId);
    const client = await db.connect();

    try {
      await client.query("BEGIN");

      await client.query(
        `UPDATE comparison_columns SET
          page = COALESCE($1,page),
          tag = COALESCE($2,tag),
          heading_title = COALESCE($3,heading_title),
          paragraph = COALESCE($4,paragraph),
          title = COALESCE($5,title),
          image = COALESCE($6,image),
          bonus_title = COALESCE($7,bonus_title),
          updated_at = NOW()
         WHERE id = $8`,
        [
          data.page,
          data.tag,
          data.heading_title,
          data.paragraph,
          data.title,
          data.image,
          data.bonus_title,
          columnId,
        ],
      );

      if (data.entries) {
        await client.query(
          `DELETE FROM comparison_entries WHERE column_id=$1`,
          [columnId],
        );

        for (const entry of data.entries) {
          await client.query(
            `INSERT INTO comparison_entries
              (column_id, entry_type, text, position)
             VALUES ($1,$2,$3,$4)`,
            [columnId, entry.entry_type, entry.text, entry.position],
          );
        }
      }

      await client.query("COMMIT");
      return { message: "Comparison updated successfully" };
    } catch (error) {
      await client.query("ROLLBACK");
      errorLogger.error(error);
      throw new Error("Failed to update comparison");
    } finally {
      client.release();
    }
  },

  /** ✅ Get comparisons by page */
  async getComparisons(page?: string) {
    let query = `SELECT * FROM comparison_columns`;
    const values: any[] = [];

    if (page) {
      query += ` WHERE page = $1`;
      values.push(page);
    }

    const columnsRes = await db.query(query, values);

    if (!columnsRes.rows.length) return null;

    // page-level info (same for all rows)
    const {
      page: pageName,
      tag,
      heading_title,
      paragraph,
    } = columnsRes.rows[0];

    const columns = [];

    for (const column of columnsRes.rows) {
      const entriesRes = await db.query(
        `SELECT entry_type, text, position
         FROM comparison_entries
         WHERE column_id = $1
         ORDER BY position`,
        [column.id],
      );

      columns.push({
        id: column.id,
        type: column.type,
        title: column.title,
        image: column.image,
        bonus_title: column.bonus_title,
        entries: entriesRes.rows,
      });
    }

    return {
      page: pageName,
      tag,
      heading_title,
      paragraph,
      columns,
    };
  },
  async getComparisonsArrange(page?: string) {
    let query = `
      SELECT *
      FROM comparison_columns
    `;
    const values: any[] = [];

    if (page) {
      query += ` WHERE page = $1`;
      values.push(page);
    }

    query += `
      ORDER BY CASE type
        WHEN 'montage' THEN 1
        WHEN 'agencies' THEN 2
        WHEN 'freelancers' THEN 3
      END
    `;

    const columnsRes = await db.query(query, values);

    if (!columnsRes.rows.length) return null;

    const {
      id,
      page: pageName,
      tag,
      heading_title,
      paragraph,
    } = columnsRes.rows[0];

    const columns = [];

    for (const column of columnsRes.rows) {
      const entriesRes = await db.query(
        `SELECT entry_type, text, position
         FROM comparison_entries
         WHERE column_id = $1
         ORDER BY position`,
        [column.id],
      );

      columns.push({
        id: column.id,
        type: column.type,
        title: column.title,
        image: column.image,
        bonus_title: column.bonus_title,
        entries: entriesRes.rows,
      });
    }

    return {
      id: id,
      page: pageName,
      tag,
      heading_title,
      paragraph,
      columns,
    };
  },
  /** ✅ Delete column */
  async deleteComparison(columnId: string) {
    await checkColumnExists(columnId);
    const res = await db.query(
      `DELETE FROM comparison_columns WHERE id=$1 RETURNING *`,
      [columnId],
    );
    return res.rows[0];
  },
};
