export interface IBrandImage {
  id: string;
  image: string;
  alt: string;
  ishide: true;
  type: string;
  width: string;
  height: string;
  sortorder: number;
}
