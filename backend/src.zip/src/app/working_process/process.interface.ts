export interface ProcessStep {
  icon: string;
  title: string;
  description: string;
  isHiden: boolean;
  image: string;
  icon_alt: string;
  alt: string;
  order_index: number;
}

export type ProcessType =
  | "podcast"
  | "shorts"
  | "thumbnail"
  | "saas"
  | "home"
  | "talkinghead";

export interface ProcessSchema {
  tag: string;
  heading_part1: string;
  heading_part2: string;
  paragraph: string;
  image: string;
  alt: string;
  type: ProcessType;
  process_steps: ProcessStep[];
}
