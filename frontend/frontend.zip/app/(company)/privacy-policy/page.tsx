import { getPageSEO } from "@/component/share/getPageSEO";
import { getData } from "@/utils/getData";

export async function generateMetadata() {
  return await getPageSEO("privacy");
}
const Privacypolicy = async () => {
  const data = await getData({ url: "api/seo/privacy" });

  const safeSchema =
    data?.data?.schema ??
    JSON.stringify({
      "@context": "https://schema.org",
      "@type": "Organization",
      name: "MontageMotion",
    });
  return (
    <div className="max-w-249 mx-auto px-2">
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: safeSchema,
        }}
      />
      <h2
        style={{ textTransform: "capitalize" }}
        className="lg:mt-60 capitalize mb-4 mt-40 text-(--text-primary) poppins font-bold text-3xl "
      >
        Privacy Policy
      </h2>
      <div className="opensans text-(--text-primary)">
        <div className="font-normal md:text-[16px] md:leading-[22.4px] text-[14px] leading-5 opensans">
          <p>Effective Date: 26 August, 2024</p>
          <p className="mt-6">
            Montage Motion (&quot;we&quot; ,&quot;our&quot; , &quot;us&quot;) is
            committed to protecting your ( collectively &quot;Customers&quot; or
            &quot;you &quot; or &quot; &quot; your &quot; ) privacy. This
            Privacy Policy explains how we collect, use, disclose, and safeguard
            your information when you visit our website
            <a href="https://montagemotion.com/">
              https://montagemotion.com/
            </a>{" "}
            (the &quot; Site &quot;),use our services, or engage with us in any
            other way . Please read this Privacy Policy carefully. If you do not
            agree with the terms of this Privacy Policy , Please do not access
            the Site , We update this Policy from time to time , so Please
            review it regularly for any changes.
          </p>
        </div>
        <div className="flex flex-col gap-5 mt-5">
          <div>
            <h3 className="mb-2 font-bold md:text-[24px] md:leading-[33.6px]  poppins">
              1. Information We Collect
            </h3>

            <ul className="font-normal md:text-[16px] md:leading-[22.4px] text-[14px] leading-5 list-disc opensans ms-6">
              <li>
                Personal Information: We may collect personal information such
                as your name, email address, phone number, billing information,
                and any other information you provide when you use our services
                or contact us.
              </li>
              <li>
                Non-Personal Information: We may collect non-personal
                information such as your IP address, browser type, device
                information, and usage data when you interact with our website.
              </li>
            </ul>
          </div>
          <div>
            <h3 className="mb-2 font-bold md:text-[24px] md:leading-[33.6px]  poppins">
              2. How We Share Your Information
            </h3>
            <p className="font-normal md:text-[16px] md:leading-[22.4px] text-[14px] leading-5 opensans">
              We may use the information we collect for various purposes,
              including :
            </p>
            <ul className="font-normal md:text-[16px] md:leading-[22.4px] text-[14px] leading-5 list-disc opensans ms-6">
              <li>To provide , operate, and maintain our services.</li>
              <li>
                To process and complete transactions,and send related
                information such as invoices and purchase.
              </li>
              <li>
                To communicate with you, including responding to your inquiries
                , sending you updates, and providing customer support.
              </li>
              <li>
                To analyze usage of our webiste and srvices to improve our
                offerings .
              </li>
              <li>To comply with legal obligations.</li>
            </ul>
          </div>
          <div>
            <h3 className="mb-2 font-bold md:text-[24px] md:leading-[33.6px]  poppins">
              3. How We Share Your Information
            </h3>
            <p className="font-normal md:text-[16px] md:leading-[22.4px] text-[14px] leading-5 opensans">
              We do not sell, trade, or otherwise transfer your personal
              information to third parties without your consent, except as
              described below:
            </p>
            <ul className="font-normal md:text-[16px] md:leading-[22.4px] text-[14px] leading-5 list-disc opensans ms-6">
              <li>
                Service Providers: We may share your information with
                third-party service providers who perform services on our
                behalf, such as payment processing, data analysis, email
                delivery, and customer support.
              </li>
              <li>
                Legal Requirements: We may disclose your information if required
                to do so by law or in response to valid requests by public
                authorities.
              </li>
              <li>
                Business Transfers: In the event of a merger, acquisition, or
                sale of all or a portion of our assets, your information may be
                transferred as part of that transaction.
              </li>
            </ul>
          </div>
          <div>
            <h3 className="mb-2 font-bold md:text-[24px] md:leading-[33.6px]  poppins">
              4. Data Security
            </h3>
            <p className="font-normal md:text-[16px] md:leading-[22.4px] text-[14px] leading-5 opensans">
              We implement appropriate technical and organizational measures to
              protect your personal information from unauthorized access,
              alteration, disclosure, or destruction. However, no method of
              transmission over the internet or method of electronic storage is
              completely secure, and we cannot guarantee its absolute security.
            </p>
          </div>
          <div>
            <h3 className="mb-2 font-bold md:text-[24px] md:leading-[33.6px]  poppins">
              5. Your Rights
            </h3>
            <p className="font-normal md:text-[16px] md:leading-[22.4px] text-[14px] leading-5 opensans">
              Depending on your location , you may have certain rights regarding
              your personal information , including :
            </p>
            <ul className="font-normal md:text-[16px] md:leading-[22.4px] text-[14px] leading-5 list-disc opensans ms-6">
              <li>
                The right to access, update, or delete the information we have
                about you.
              </li>
              <li>
                The right to object to or restrict the processing of your
                information.
              </li>
              <li>
                The right to withdraw your consent at any time where we rely on
                your consent to process your personal information.
              </li>
            </ul>
            <p className="font-normal md:text-[16px] md:leading-[22.4px] text-[14px] leading-5 opensans">
              To exercise these rights, please contact us at
              imomofficial@gmail.com
            </p>
          </div>

          <div>
            <h3 className="mb-2 font-bold md:text-[24px] md:leading-[33.6px]  poppins">
              6. Third-Party Links
            </h3>
            <p className="font-normal md:text-[16px] md:leading-[22.4px] text-[14px] leading-5 opensans">
              Our website may contain links to third-party websites or services
              that are not operated by us. We are not responsible for the
              privacy practices of these third-party sites. We encourage you to
              review the privacy policies of any third-party sites you visit.
            </p>
          </div>
          <div>
            <h3 className="mb-2 font-bold md:text-[24px] md:leading-[33.6px]  poppins">
              7. Changes to This Privacy Policy
            </h3>
            <p className="font-normal md:text-[16px] md:leading-[22.4px] text-[14px] leading-5 opensans">
              We may update this Privacy Policy from time to time. We will
              notify you of any changes by posting the new Privacy Policy on our
              website. You are advised to review this Privacy Policy
              periodically for any changes.
            </p>
          </div>

          <div>
            <h3 className="mb-2 font-bold md:text-[24px] md:leading-[33.6px]  poppins">
              8. Contact Us
            </h3>
            <p className="font-normal md:text-[16px] md:leading-[22.4px] text-[14px] leading-5 opensans">
              {" "}
              If you have any questions or concerns about this Privacy Policy
              periodically for any changes.
              <br /> <br />
              Montage Motion
              <br />
              Email: imonofficial@gamil.com
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Privacypolicy;
