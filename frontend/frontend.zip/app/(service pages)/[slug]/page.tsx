import { getPageSEO } from "@/component/share/getPageSEO";
import { getData } from "@/utils/getData";
import React from "react";
import { getTypeFromSlug } from "./getTypeFromSlug";
import PageContactsections from "../(servicepage-component)/PageContactsections";
import PageProcesssection from "../(servicepage-component)/PageProcesssection";
import PagePricing from "../(servicepage-component)/PagePricing";
import PageServicesection from "../(servicepage-component)/PageServicesection";

import ShortsHeader from "../(servicepage-component)/ShortsHeader";
import PartnersSection from "@/component/home/PatnersSection";
import PageHomeHero from "../(servicepage-component)/PageHomeHero";
import PodacstHeader from "../(servicepage-component)/PodacstHeader";
import PodcastInsight from "../(servicepage-component)/PodcastInsight";
import SaasInshight from "../(servicepage-component)/SaasInshight";
import PageWhychooseus from "../(servicepage-component)/PageWhychooseus";
import Thumbnailworksection from "../(servicepage-component)/Thumbnailworksection";
import HomeFaqSection from "@/component/share/HomeFaqSection";
import ComparisonCards from "@/component/home/PriceComparison";
import TestimonialSection from "@/component/share/Testimonial";
export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const type = await getTypeFromSlug(slug);
  return await getPageSEO(type as string);
}
const ServicePage = async ({
  params,
}: {
  params: Promise<{ slug: string }>;
}) => {
  const { slug } = await params;
  const data = await getData({
    url: `api/website/services/data?type=${slug}`,
  });
  // console.log("scham ====================>", data);
  const safeSchema =
    data?.data?.schema ??
    JSON.stringify({
      "@context": "https://schema.org",
      "@type": "Organization",
      name: "MontageMotion",
    });
    // console.log(data?.data?.home_hero)
  return (
    <div className="lg:min-h-screen text-black mt-4 ">
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: safeSchema,
        }}
      />
      {data?.data?.short_hero && <ShortsHeader data={data?.data?.short_hero} />}
      {data?.data?.home_hero && <PageHomeHero data={data?.data?.home_hero} />}
      {data?.data?.podcast_hero && (
        <PodacstHeader data={data?.data?.podcast_hero} />
      )}
      {data?.data?.our_clients && (
        <PartnersSection data={data?.data?.our_clients} />
      )}
      {data?.data?.work && (
        <Thumbnailworksection works={data?.data?.work} slug={slug} />
      )}
      {slug === "saas-explainer" && (
        <>
          <SaasInshight />
        </>
      )}
      {data?.data?.service && (
        <PageServicesection data={data?.data?.service?.[0]} />
      )}
      {data?.data?.pricing && <PagePricing pricing={data?.data?.pricing} />}
      {data?.data?.testimonial && (
        <TestimonialSection
          data={data?.data?.testimonial}
          title="What Our Clients Say"
          description="Montage Motion is an Advertising and Digital Agency specializing in Influencer Marketing"
        />
      )}
      {data?.data?.process && <PageProcesssection data={data?.data?.process} />}
      {data?.data?.insight && <PodcastInsight data={data?.data?.insight} />}
      {data?.data?.comparison && (
        <ComparisonCards data={data?.data?.comparison?.[0]} />
      )}
      {data?.data?.whychooseus && (
        <PageWhychooseus data={data?.data?.whychooseus ?? []} />
      )}
      {data?.data?.faq && <HomeFaqSection data={data?.data?.faq} />}
      {data?.data?.contact && <PageContactsections />}
    </div>
  );
};

export default ServicePage;
