import { getPageSEO } from "@/component/share/getPageSEO";
import JsonLd from "@/component/share/JsonLd";
import { getData } from "@/utils/getData";

export const revalidate = 900;

export async function generateMetadata() {
  return await getPageSEO("terms");
}
const Termsandconditions = async () => {
  const data = await getData({ url: "api/seo/terms" });

  return (
    <div className="max-w-249 mx-auto px-2 ">
      <JsonLd value={data?.data?.schema} />
      <h2 className="mb-3 text-3xl font-bold capitalize text-(--text-primary) lg:mt-60 mt-40 poppins">
        Terms and Conditions
      </h2>
      <div className="opensans text-(--text-primary)">
        <div className="font-normal md:text-[16px] md:leading-[22.4px] text-[14px] leading-5 opensans">
          <p>Effective Date: 26 August, 2024</p>
          <p className="mt-4">
            Welcome to Montage Motion (&quot;we&quot;, &quot;our&quot;, or
            &quot;us&quot;). These Terms and Conditions (&quot;Terms&quot;)
            govern your use of our website{" "}
            <a href="https://montagemotion.com/">https://montagemotion.com/</a>{" "}
            , our services, and any other interactions you have with us. By
            accessing or using our services, you agree to be bound by these
            Terms.
          </p>
        </div>
        <div className="flex flex-col gap-5 mt-5">
          <div>
            <h3 className="mb-2 font-bold md:text-[24px] md:leading-[33.6px]  poppins">
              1. Acceptance of Terms :{" "}
            </h3>
            <p className="font-normal md:text-[16px] md:leading-[22.4px] text-[14px] leading-5 opensans">
              {" "}
              By accessing or using our services, you acknowledge that you have
              read, understood, and agree to be bound by these Terms and our
              Privacy Policy. If you do not agree with these Terms, please do
              not use our services.
            </p>
          </div>
          <div>
            <h3 className="mb-2 font-bold md:text-[24px] md:leading-[33.6px]  poppins">
              2. Services :{" "}
            </h3>
            <p className="font-normal md:text-[16px] md:leading-[22.4px] text-[14px] leading-5 opensans">
              {" "}
              Montage Motion provides video editing services and other related
              services (Graphic Design, UI/UX design, Website Development &
              Digital Marketing ). We reserve the right to modify, suspend, or
              discontinue any of our Services at any time without notice. We are
              not liable to you or any third party for any modification,
              suspension, or discontinuation of our Services.
            </p>
          </div>
          <div>
            <h3 className="mb-2 font-bold md:text-[24px] md:leading-[33.6px]  poppins">
              3. User Responsibilities :{" "}
            </h3>
            <ul className="font-normal md:text-[16px] md:leading-[22.4px] text-[14px] leading-5 list-disc opensans ms-6">
              <li>
                Accuracy of Information: You agree to provide accurate, current,
                and complete information when using our Services or creating an
                account with us.
              </li>
              <li>
                Prohibited Activities: You agree not to use our Services for any
                unlawful purpose or in any way that could harm or disrupt our
                operations or reputation. This includes, but is not limited to,
                transmitting harmful software, infringing on intellectual
                property rights, or engaging in any fraudulent activities.
              </li>
            </ul>
          </div>
          <div>
            <h3 className="mb-2 font-bold md:text-[24px] md:leading-[33.6px]  poppins">
              4. User Responsibilities :{" "}
            </h3>
            <ul className="font-normal md:text-[16px] md:leading-[22.4px] text-[14px] leading-5 list-disc opensans ms-6">
              <li>
                Ownership: All content, materials, and intellectual property
                rights related to our Services, including but not limited to
                text, graphics, logos, images, and software, are owned by
                Montage Motion or our licensors.
              </li>
              <li>
                Use of Content: You may not reproduce, distribute, modify, or
                create derivative works from any content or materials obtained
                from our Services without our prior written consent.
              </li>
            </ul>
          </div>
          <div>
            <h3 className="mb-2 font-bold md:text-[24px] md:leading-[33.6px]  poppins">
              5. Payment and Refunds:{" "}
            </h3>
            <ul className="font-normal md:text-[16px] md:leading-[22.4px] text-[14px] leading-5 list-disc opensans ms-6">
              <li>
                Pricing: The pricing for our Services is listed on our website
                or communicated to you directly. We reserve the right to change
                our pricing at any time without notice.
              </li>
              <li>
                Payment: You agree to pay all fees and charges associated with
                our Services as described on our website or in a separate
                agreement.
              </li>
              <li>
                Refunds: Refunds will be provided only in accordance with our
                Refund Policy, if applicable. Please review the Refund Policy on
                our website for more details.
              </li>
            </ul>
          </div>
          <div>
            <h3 className="mb-2 font-bold md:text-[24px] md:leading-[33.6px]  poppins">
              6. Limitation of Liability :{" "}
            </h3>
            <ul className="font-normal md:text-[16px] md:leading-[22.4px] text-[14px] leading-5 list-disc opensans ms-6">
              <li>
                No Warranties: Our Services are provided &quot;as is&quot; and
                &quot;as available&quot; without any warranties, express or
                implied, including but not limited to warranties of
                merchantability, fitness for a particular purpose, or
                non-infringement.
              </li>
              <li>
                Limitation of Liability: In no event shall Montage Motion be
                liable for any indirect, incidental, special, consequential, or
                punitive damages arising out of or in connection with your use
                of our Services. Our total liability to you for any claims
                arising from or related to our Services shall not exceed the
                amount you paid to us for the Services.
              </li>
            </ul>
          </div>
          <div>
            <h3 className="mb-2 font-bold md:text-[24px] md:leading-[33.6px]  poppins">
              7. Indemnification:{" "}
            </h3>
            <p className="font-normal md:text-[16px] md:leading-[22.4px] text-[14px] leading-5 opensans">
              {" "}
              You agree to indemnify, defend, and hold harmless Montage Motion,
              its officers, directors, employees, and agents from and against
              any and all claims, liabilities, damages, losses, or expenses,
              including reasonable attorneys&apos; fees, arising out of or in
              any way connected with your use of our Services or your violation
              of these Terms.
            </p>
          </div>
          {/* new  */}
          <div>
            <h3 className="mb-2 font-bold md:text-[24px] md:leading-[33.6px]  poppins">
              8. Termination :{" "}
            </h3>
            <p className="font-normal md:text-[16px] md:leading-[22.4px] text-[14px] leading-5 opensans">
              {" "}
              We reserve the right to terminate or suspend your access to our
              Services at any time, with or without cause, and without prior
              notice. Upon termination, you must cease all use of our Services
              and delete any materials or content obtained from our Services.
            </p>
          </div>
          <div>
            <h3 className="mb-2 font-bold md:text-[24px] md:leading-[33.6px]  poppins">
              9. Governing Law :{" "}
            </h3>
            <p className="font-normal md:text-[16px] md:leading-[22.4px] text-[14px] leading-5 opensans">
              {" "}
              These Terms shall be governed by and construed in accordance with
              the laws of Bangladesh, without regard to its conflict of law
              principles. Any legal action or proceeding arising out of or
              related to these Terms shall be brought exclusively in the courts
              of Bangladesh.
            </p>
          </div>
          <div>
            <h3 className="mb-2 font-bold md:text-[24px] md:leading-[33.6px]  poppins">
              10. Changes to These Terms :{" "}
            </h3>
            <p className="font-normal md:text-[16px] md:leading-[22.4px] text-[14px] leading-5 opensans">
              {" "}
              We may update these Terms from time to time. We will notify you of
              any changes by posting the new Terms on our website. You are
              advised to review these Terms periodically for any changes. Your
              continued use of our Services after the posting of any changes
              constitutes your acceptance of those changes
            </p>
          </div>

          <div>
            <h3 className="mb-2 font-bold md:text-[24px] md:leading-[33.6px]  poppins">
              11. Contact Us :{" "}
            </h3>
            <p className="font-normal md:text-[16px] md:leading-[22.4px] text-[14px] leading-5 opensans">
              {" "}
              If you have any questions or concerns about these Terms, please
              contact us at : <br /> <br />
              Montage Motion <br />
              Email: imonofficial@gmail.com
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Termsandconditions;
