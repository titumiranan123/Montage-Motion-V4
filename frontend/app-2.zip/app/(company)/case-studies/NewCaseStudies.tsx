// components/CaseStudyCard.tsx

import { ArrowRight } from "lucide-react";
import Image from "next/image";
import Link from "next/link";
import { getSafeImageSrc } from "@/utils/media";

interface CaseStudyItem {
  id: string;
  slug?: string;
  type?: string | null;
  status?: 'published' | 'draft' | 'archived' | null;
  title?: string | null;
  description?: string | null;
  image_url?: string | null;
  image_alt?: string | null;
  metrics?: Metric[];
  created_at?: string | null;
}

interface Metric {
  label: string;
  value: string;
}

function formatDate(iso?: string | null): string {
  if (!iso) return "";

  return new Date(iso).toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  });
}

function formatType(type?: string | null): string {
  if (!type) return "Case Study";

  return type.replace(/_/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase());
}

interface CaseStudyCardProps {
  item: CaseStudyItem;
}

export default function CaseStudyCard({ item }: CaseStudyCardProps) {
  const metrics = Array.isArray(item.metrics)
    ? item.metrics.filter((metric) => metric?.label && metric?.value)
    : [];
  const href = `/case-studies/${item.slug}`;

  return (
    <Link href={href} className="bg-white border border-gray-200 rounded-xl overflow-hidden cursor-pointer transition-all duration-200 hover:border-blue-300 hover:shadow-md max-w-sm block">

      {/* Image */}
      <div className="relative h-48 overflow-hidden">
        <Image
          src={getSafeImageSrc(item.image_url)}
          alt={item.image_alt || item.title || "Graphic work"}
          fill
          sizes="(max-width: 639px) 100vw, 384px"
          className="w-full h-full object-cover"
        />
        <span className="absolute top-3 left-3 bg-blue-50 text-[#1FB5DD] text-[11px] font-medium px-3 py-1 rounded-md uppercase tracking-wide">
          {formatType(item.type)}
        </span>
      </div>

      {/* Body */}
      <div className="p-5">
        <h3 className="text-[17px] font-semibold text-gray-900 leading-snug mb-2">
          {item.title}
        </h3>
        <p className="text-[13px] text-gray-500 leading-relaxed mb-4 line-clamp-3">
          {item.description}
        </p>

        {/* Metrics */}
        <div className="flex items-center gap-4 mb-4">
          {metrics.map((m, i) => (
            <div key={m.label} className="flex items-center gap-4">
              {i !== 0 && <div className="w-px h-8 bg-gray-200" />}
              <div className="flex flex-col gap-0.5">
                <span className="text-[11px] text-gray-400 uppercase tracking-widest">
                  {m.label}
                </span>
                <span className="text-lg font-semibold text-[#1FB5DD]">
                  {m.value}
                </span>
              </div>
            </div>
          ))}
        </div>

        {/* Footer */}
        <div className="border-t border-gray-100 pt-3 flex items-center justify-between">
          <span className="text-xs text-gray-400">{formatDate(item.created_at)}</span>
          <span
            className="text-[14px] text-[#1FB5DD] hover:text-[#1FB5DD] flex items-center gap-1 transition-colors active:scale-90"
          >
            Read case study  <ArrowRight size={14} className="-rotate-45"/>
          </span>
        </div>
      </div>
    </Link>
  );
}
