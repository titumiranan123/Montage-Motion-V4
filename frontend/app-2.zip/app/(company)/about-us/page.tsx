import HeaderService from "@/component/about/Header";
import OurMission from "./OurMission";
import OurTeam from "./OurTeam";
import OurStory from "./OurStory";
import { getPageSEO } from "@/component/share/getPageSEO";
import ContactSection from "@/component/share/ContactSection";
import JsonLd from "@/component/share/JsonLd";
import { getData } from "@/utils/getData";
import PartnersSection from "@/component/home/PatnersSection";
import HomeFaqSection from "@/component/share/HomeFaqSection";
import TeamimageSection from "./TeamimageSection";
export const revalidate = 300;
// Metadata for SEO
export async function generateMetadata() {
  return await getPageSEO("about");
}

const AboutUs = async () => {
  const data = await getData({
    url: `api/website/data?type=about&table=brand,members,faq,ourstory,teamimage`,
  });
  return (
    <div className=" mt-2 md:pt-0 ">
      <JsonLd value={data?.data?.schema} />
      {data?.data?.header && (
        <div className="headerbg rounded-[40px]  px-2 xl:px-15 mx-auto pb-15 pt-16 mb-10">
          <HeaderService mainIntro={data?.data?.header || null} />
        </div>
      )}
      {data?.data?.brand && <PartnersSection data={data?.data?.brand ?? []} />}
      {/* <Brand /> */}
      <OurMission />

      <OurStory data={data?.data?.ourstory?.[0]} />
      {data?.data?.members && <OurTeam members={data?.data?.members} />}
      <TeamimageSection data={data?.data?.teamimage} />
      {data?.data?.faq && <HomeFaqSection data={data?.data?.faq} />}
      <ContactSection />
    </div>
  );
};

export default AboutUs;
