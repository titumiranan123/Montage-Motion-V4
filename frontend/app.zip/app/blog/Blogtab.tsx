"use client";
import { Search } from "lucide-react";
import { useSearchParams } from "next/navigation";
import { useRouter } from "next/navigation";
import React, { useState } from "react";

const Blogtab = () => {
  const router = useRouter();
  const searchParams = useSearchParams();
  const currentTab = searchParams.get("cat") || "all";
  const [activeTab, setActiveTab] = useState(currentTab);
  const handleTabClick = (href: string) => {
    setActiveTab(href);
    const newUrl = `?cat=${href}`;
    router.replace(newUrl);
  };
  const tabConfig = [
    {
      title: "All",
      href: "all",
    },
    {
      title: "Video Editing",
      href: "video-editing",
    },
    {
      title: "Content Marketing",
      href: "content-marketing",
    },
    {
      title: "Design & Branding",
      href: "design-branding",
    },
    {
      title: "Social Media Trends",
      href: "social-media-trends",
    },
    {
      title: "Podcasting Tips",
      href: "podcasting-tips",
    },
    {
      title: "Case Studies",
      href: "case-studies",
    },
  ];

  const handleSearch = (e: any) => {
    const value = e.target.value;
    const newUrl = `?cat=${activeTab}&search=${encodeURIComponent(value)}`;
    router.replace(newUrl);
  };
  return (
    <div data-aos="fade-up" data-aos-delay={400}>
      <style>
        {`
        .searchbg{
          background: linear-gradient(250.64deg, rgba(51, 87, 163, 0.5) 0%, rgba(51, 87, 163, 0) 50%, rgba(51, 87, 163, 0.5) 100%);
        }
        `}
      </style>
      {/* search hidden by tailwind class */}
      <div className="searchbg group w-[123px] hidden  justify-center items-center mx-auto  rounded-full p-[1px] mt-5 focus-within:w-[260px] transition-all duration-300">
        <button className="w-[120px] group-focus-within:w-[260px] flex items-center gap-2 bg-black rounded-full px-3 py-2 transition-all duration-300 ">
          {/* Search Icon */}
          <Search className="text-white" />

          {/* Search Input */}
          <input
            onChange={handleSearch}
            type="text"
            placeholder="Search"
            className="bg-transparent text-white placeholder-gray-400 outline-none border-none w-[56px] group-focus-within:w-[200px] transition-all duration-300 ease-in-out"
          />
        </button>
      </div>
      <div className="searchbg max-w-[1002px] rounded-[56px] p-[1px] max-h-[57px] mx-auto mt-8">
        <div className="flex  justify-start lg:justify-center items-center gap-6  pb-2  max-w-[1002px]  max-h-[55px] rounded-[56px] py-[11px] px-3 bg-black flex-nowrap overflow-x-scroll scrollbar-hide ">
          {tabConfig.map((tab) => (
            <button
              key={tab.href}
              onClick={() => handleTabClick(tab.href)}
              className={`py-2 px-3 text-white opensans font-[400] text-[14px]  rounded-[36px] transition-colors whitespace-nowrap ${
                activeTab === tab.href ? " bg-[#2B6AB2] font-semibold" : ""
              }`}
            >
              {tab.title}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Blogtab;
