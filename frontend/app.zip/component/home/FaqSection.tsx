import React from "react";

const FaqSection = () => {
  return <div>Faq Sections</div>;
};

export default FaqSection;
