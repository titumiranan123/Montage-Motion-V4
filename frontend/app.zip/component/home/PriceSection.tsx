import React from "react";

const PriceSection = () => {
  return <div>Price Section</div>;
};

export default PriceSection;
