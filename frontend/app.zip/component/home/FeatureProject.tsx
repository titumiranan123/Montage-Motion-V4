import React from "react";

const FeatureProject = () => {
  return <div>feature project</div>;
};

export default FeatureProject;
