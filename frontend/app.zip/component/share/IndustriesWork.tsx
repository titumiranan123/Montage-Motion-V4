import React from "react";
import Heading from "./Headering";
import { TabsClient } from "./IndustryTabClient";

const IndustriesWork = () => {
  return (
    <div>
      <div>{/* <TabsClient tabs={} /> */}</div>
    </div>
  );
};

export default IndustriesWork;
