import React from "react";

const Tabcontainer = ({}) => {
  return <div></div>;
};

export default Tabcontainer;
